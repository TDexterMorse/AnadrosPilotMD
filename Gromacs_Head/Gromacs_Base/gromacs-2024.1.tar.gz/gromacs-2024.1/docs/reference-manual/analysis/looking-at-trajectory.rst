Looking at your trajectory
--------------------------

| Before analyzing your trajectory it is often informative to look at
  your trajectory first. There are several programs that can read 
  the |Gromacs| trajectory formats – have a look at our `webpage`_ 
  for up-to-date links.

